﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProductAdmin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (TextBox1.Text != "")
        {
            Response.Redirect("AdminCategorySearch.aspx?CategoryAdmin=" + TextBox1.Text);
        }
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        if (TextBox2.Text != "")
        {
            Response.Redirect("AdminNameSearch.aspx?Name=" + TextBox2.Text);
        }
    }
}