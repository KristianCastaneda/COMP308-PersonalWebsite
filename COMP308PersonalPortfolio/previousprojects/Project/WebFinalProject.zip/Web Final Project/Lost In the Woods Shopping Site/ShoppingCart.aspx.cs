﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Net;
using System.Web.UI;
using System.Diagnostics;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ShoppingCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    if (Request.QueryString["ID"] != null)
                    {
                        Add(Convert.ToInt32(Request.QueryString["quant"]));
                    }
                }
                catch
                {
                    Response.Redirect("Error.aspx");
                }
                GridView1.DataSource = GetDataSetCart();
                GridView1.DataBind();
            }
            else
            {
                Response.Redirect("~/Account/Login.aspx");
            }
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    public DataSet GetDataSetCart()
    {
        if (Session["Cart"] == null)
        {
            DataSet ds = new DataSet();
            DataColumn colID = new DataColumn("ID", System.Type.GetType("System.Int32"), "");
            DataTable dt = new DataTable("ShopCart");
            dt.Columns.Add(colID);
            dt.Columns.Add("ProductName", System.Type.GetType("System.String"), "");
            dt.Columns.Add("Quantity", System.Type.GetType("System.Int32"), "");
            dt.Columns.Add("Price", System.Type.GetType("System.Double"), "");
            dt.Columns.Add("Subtotal", System.Type.GetType("System.Double"), "Quantity*Price");
            dt.Columns.Add("Total", System.Type.GetType("System.Double"), "SUM(Subtotal)");

            //key field
            DataColumn[] keys = new DataColumn[1];
            keys[0] = colID;
            dt.PrimaryKey = keys;
            ds.Tables.Add(dt);
            Session["Cart"] = ds;
            return ds;
        }
        else
        {
            return (Session["Cart"] as DataSet);
        }
    }

    private void Add(int quantity)
    {
        //search database
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
        string aSQL = "select ProductName, ProductPrice from Product where ProductID=" + Request.QueryString["ID"].ToString();

        try
        {
            //open connection
            con.Open();
            SqlCommand cmd = new SqlCommand(aSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            //get data of DataSet in Session
            DataTable dt = GetDataSetCart().Tables[0];
            //find Product
            DataRow row = dt.Rows.Find(Request.QueryString["ID"]);
            //add line
            if (row == null)
            {
                row = dt.NewRow();
                row["ID"] = Request.QueryString["ID"];
                row["ProductName"] = reader["ProductName"];
                row["Quantity"] = quantity;
                row["Price"] = reader["ProductPrice"];
                dt.Rows.Add(row);
            }
            else
            {
                int qtd = Convert.ToInt32(row["Quantity"]);
                qtd = quantity;
                row["Quantity"] = qtd;
            }
        }
        finally
        {
            con.Close();
        }
    }

    private void Remove(int aId)
    {
        DataSet ds = GetDataSetCart();
        DataRow row = ds.Tables[0].Rows.Find(aId);
        if (row != null)
        {
            ds.Tables[0].Rows.Remove(row);
            ds.AcceptChanges();
            GridView1.DataSource = GetDataSetCart();
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Remove(Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value));
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[3].Text = "Total: ";
            e.Row.Cells[4].Text = String.Format("{0:c}", GetDataSetCart().Tables[0].Rows[0]["Total"]);
        }
    }


    private void Checkout()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());

        try
        {
            // open connection
            SqlCommand cmd = new SqlCommand("sp_InsertSales", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Date", SqlDbType.DateTime, 0, "SalesDate").Value = DateTime.Now;
            try
            {
                cmd.Parameters.Add("@Value", SqlDbType.Decimal, 18, "SalesValue").Value = GetDataSetCart().Tables[0].Rows[0]["Total"];
            }
            catch
            {
                Response.Redirect("Error.aspx");
            }
            cmd.Parameters.Add("@UserID", SqlDbType.Int, 0, "UserId").Value = Convert.ToInt32(1);
            
            using(WebClient client = new WebClient())
            {
            System.Collections.Specialized.NameValueCollection reqparm = new System.Collections.Specialized.NameValueCollection();

            reqparm.Add("cmd", "_cart");
            reqparm.Add("add", "1");
            reqparm.Add("business", "Lost In The Woods: The Game");
            reqparm.Add("item_name", "LITW Paypal Sale");
            reqparm.Add("amount", "1000.00");
            reqparm.Add("shipping", "1.00");
            reqparm.Add("return", "http://www.yourwebsite.com/success.html");
            reqparm.Add("cancel_return", "http://www.yourwebsite.com/cancel.html");
            reqparm.Add("bn", "PP-ShopCartBF:x-click-but22.gif:NonHosted");

            byte[] responsebytes = client.UploadValues("https://www.paypal.com/cgi-bin/webscr", "POST", reqparm);
            string responsebody = Encoding.UTF8.GetString(responsebytes);

            
            }       
            
            
            con.Open();
            int aKey = Convert.ToInt32(cmd.ExecuteScalar());
            foreach (DataRow row in GetDataSetCart().Tables[0].Rows)
            {
                SqlCommand cmdItem = new SqlCommand("sp_InsertItemSales", con);
                cmdItem.CommandType = CommandType.StoredProcedure;
                cmdItem.Parameters.Add("@IDSales", SqlDbType.Int, 0, "SalesID").Value = aKey;
                cmdItem.Parameters.Add("@IDProduct", SqlDbType.Int, 0, "ProductID").Value = row["ID"];
                cmdItem.Parameters.Add("@ValueProduct", SqlDbType.Decimal, 18, "ProductSalesPrice").Value = row["Price"];
                cmdItem.Parameters.Add("@Quantity", SqlDbType.Int, 0, "Quantity").Value = row["Quantity"];
                cmdItem.ExecuteNonQuery();
            }
            Session["Total"] = GetDataSetCart().Tables[0].Rows[0]["Total"];
            Session["Cart"] = null;            
        }
        finally
        {
            con.Close();
            Response.Redirect("Checkout.aspx");
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Checkout();
    }
}