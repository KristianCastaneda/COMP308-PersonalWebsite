﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProductInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShoppingCart.aspx?NAME=" + Request.QueryString["NAME"] + "&quant=" +
        (FormView1.FindControl("TextBox2") as TextBox).Text);
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("ShoppingCart.aspx?ID=" + Request.QueryString["ID"] + "&quant=" +
            (FormView1.FindControl("TextBox2") as TextBox).Text);
    }
}